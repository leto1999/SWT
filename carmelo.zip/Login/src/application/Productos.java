package application;


	import java.time.LocalDate;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
	import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
	import javafx.beans.property.SimpleObjectProperty;
	import javafx.beans.property.SimpleStringProperty;
	import javafx.beans.property.StringProperty;

	/**
	 * Model class for a Person.
	 *
	 * @author Marco Jakob
	 */
	public class Productos {

	    private final StringProperty Descripcion1;
	    private final SimpleIntegerProperty Stock1;
	    private final StringProperty Descripcion;
	    private final IntegerProperty Stock;
	    private final DoubleProperty Precio;
	    private final ObjectProperty<LocalDate> FechaDeFabricacion;

	    /**
	     * Default constructor.
	     */
	    public Productos() {
	        this(null, 0);
	    }
	    
	    /**
	     * Constructor with some initial data.
	     * 
	     * @param Descripcion1
	     * @param Stock1
	     */
	    public Productos(String Descripcion1, int Stock1) {
	        this.Descripcion1 = new SimpleStringProperty(Descripcion1);
	        this.Stock1 = new SimpleIntegerProperty(Stock1);
	        
	        // Some initial dummy data, just for convenient testing.
	        this.Descripcion = new SimpleStringProperty("some Descripcion");
	        this.Stock = new SimpleIntegerProperty();
	        this.Precio = new SimpleDoubleProperty();
	        this.FechaDeFabricacion = new SimpleObjectProperty<LocalDate>(LocalDate.of(1999, 2, 21));
	    }
	    
	    public String getDescripcion1() {
	        return Descripcion1.get();
	    }

	    public void setDescripcion1(String Descripcion1) {
	        this.Descripcion1.set(Descripcion1);
	    }
	    
	    public StringProperty Descripcion1Property() {
	        return Descripcion1;
	    }

	    public Integer getStock1() {
	        return Stock1.get();
	    }

	    public void setStock1(Integer Stock1) {
	        this.Stock1.set(Stock1);
	    }
	    
	    public IntegerProperty Stock1Property() {
	        return Stock1;
	    }

	    public String getDescripcion() {
	        return Descripcion.get();
	    }

	    public void setDescripcion(String Descripcion) {
	        this.Descripcion.set(Descripcion);
	    }
	    
	    public StringProperty DescripcionProperty() {
	        return Descripcion;
	    }

	    public int getStock() {
	        return Stock.get();
	    }

	    public void setStock(int Stock) {
	        this.Stock.set(Stock);
	    }
	    
	    public IntegerProperty StockProperty() {
	        return Stock;
	    }

	    public Double getPrecio() {
	        return Precio.get();
	    }

	    public void setPrecio(Double Precio) {
	        this.Precio.set(Precio);
	    }
	    
	    public DoubleProperty PrecioProperty() {
	        return Precio;
	    }

	    public LocalDate getFechaDeFabricacion() {
	        return FechaDeFabricacion.get();
	    }

	    public void setFechaDeFabricacion(LocalDate FechaDeFabricacion) {
	        this.FechaDeFabricacion.set(FechaDeFabricacion);
	    }
	    
	    public ObjectProperty<LocalDate> FechaDeFabricacionProperty() {
	        return FechaDeFabricacion;
	    }
	}

