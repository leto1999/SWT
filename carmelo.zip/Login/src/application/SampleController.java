package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class SampleController {

    @FXML
    private Label LabelContrase�a;

    @FXML
    private Label LabelCorreo;

    @FXML
    private TextArea TextContrase�a;

    @FXML
    private TextArea TextCorreo;

    @FXML
    private Button IniciarSesion;
    
   public void Login(ActionEvent event) {
    	//Creamos la alerta que aparecer� para decirnos si hemos introducido bien las credenciales
    	Alert alert = new Alert(AlertType.INFORMATION);
    	alert.setTitle("Informaci�n");
    	alert.setHeaderText(null);
    	
    	//Variables ficticias para emular un inicio de sesi�n
    	String email = "prueba@gmail.com";
    	String password = "123456";
    	
    	//Comprobamos si coinciden los datos del login
    	if(TextCorreo.getText().equals(email) && TextContrase�a.getText().equals(password)) {
    		try {
    	        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("vistalogin.fxml"));
    	        Parent root1 = (Parent) fxmlLoader.load();
    	        Stage stage = new Stage();
    	        stage.setScene(new Scene(root1));  
    	        stage.show();
    	    } catch(Exception e) {
    	        e.printStackTrace();
    	    }
    	
    		//Si coincide, nos muestra el siguiente mensaje
    		//alert.setContentText("Ha iniciado sesi�n correctamente");
    	}else {
    		//Si no hemos escrito bien nuestra credenciales, nos muestra este otro
    		//alert.setContentText("Email y/o contrase�a incorrectos");
    		System.out.println(email +" "+password+" "+TextCorreo.getText()+" "+TextContrase�a.getText()+" ");
    	}
    	
    	alert.showAndWait();
    	
    	
    }


}
