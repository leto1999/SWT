package application;
	
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	
	private ObservableList<Productos> ProductosData = FXCollections.observableArrayList();

    /**
     * Constructor
     * @return 
     */
    public void MainApp() {
        // Add some sample data
        ProductosData.add(new Productos("Camiseta", 12));
        ProductosData.add(new Productos("Balon", 3));
        ProductosData.add(new Productos("Bufanda", 5));
        ProductosData.add(new Productos("Bombones", 2));
        ProductosData.add(new Productos("Hornos", 6));
        ProductosData.add(new Productos("Disfraces", 20));
       
    }
  
    /**
     * Returns the data as an observable list of Productoss. 
     * @return
     */
    public ObservableList<Productos> getProductosData() {
        return ProductosData;
    }
	@Override
	public void start(Stage primaryStage) {
		try {
			Pane root = (Pane)FXMLLoader.load(getClass().getResource("Sample.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
